chrome.devtools.panels.create(
    'NetworkRequests',
    null, // No icon path
    'Panel/NetworkRequests.html',
    null // no callback needed
);
